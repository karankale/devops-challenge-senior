# SimpleTimeService EKS Infrastructure

This repo uses Terraform to deploy an EKS cluster and run a containerized app with ALB Ingress.
